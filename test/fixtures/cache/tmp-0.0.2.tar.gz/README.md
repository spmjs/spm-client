# tmp [![spm version](http://spmjs.io/badge/tmp)](http://spmjs.io/package/tmp)

---

An awesome spm package!

---

## Install

```
$ spm install tmp --save
```

## Usage

```js
var tmp = require('tmp');
// use tmp
```
