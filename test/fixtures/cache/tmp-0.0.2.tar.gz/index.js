var tmp;

module.exports = tmp;
